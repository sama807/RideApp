﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRide
{
    public class Admin
    {
        static List<Driver> driverList = new List<Driver>();

        public Admin()
        {

        }
        public void addDriver()
        {
            Driver newDriver = new Driver();
            newDriver.id = driverList.Count + 1;
            Console.Write(" Enter Name: ");
            Console.ForegroundColor = ConsoleColor.Green;
            string dName = Console.ReadLine();
            newDriver.Name = dName;
            Console.ResetColor();


            Console.Write(" Enter Age: ");
            Console.ForegroundColor = ConsoleColor.Green;
            int age = Convert.ToInt32(Console.ReadLine());
            newDriver.Age = age;
            Console.ResetColor();


            Console.Write(" Enter Address: ");
            Console.ForegroundColor = ConsoleColor.Green;
            string address = Console.ReadLine();
            newDriver.Address = address;
            Console.ResetColor();


            Console.Write(" Enter Gender: ");
            Console.ForegroundColor = ConsoleColor.Green;
            string gender = Console.ReadLine();
            newDriver.Gender = gender;
            Console.ResetColor();

            Console.Write(" Enter PhoneNo: ");
            Console.ForegroundColor = ConsoleColor.Green;
            string phoneNo = Console.ReadLine();
            bool isAllDigits = true;
            foreach (char ch in phoneNo)
            {
                if (!char.IsDigit(ch))
                {
                    isAllDigits = false;
                    break;
                }
            }
            if (isAllDigits)
                newDriver.PhoneNo = phoneNo;
            else
            {
                Console.WriteLine(" Invalid phone Number: Should contain only digits ");
            }

            newDriver.PhoneNo = phoneNo;
            Console.ResetColor();


            Vehicle vehicle = new Vehicle();
            newDriver.Vehicle = new Vehicle();
            RideDataBase rd=new RideDataBase();

            Console.Write(" Enter Vehicle Type: ");
            Console.ForegroundColor = ConsoleColor.Green;
            string vehType = Console.ReadLine();
            vehicle.Type= vehType;
            Console.ResetColor();


            Console.Write(" Enter Vehicle Model: ");
            Console.ForegroundColor = ConsoleColor.Green;
            string model = Console.ReadLine();
            vehicle.Model= model;
            Console.ResetColor();


            Console.Write(" Enter Vehicle License_plate: ");
            Console.ForegroundColor = ConsoleColor.Green;
            string Licplate = Console.ReadLine();
            vehicle.License_plate= Licplate;
            Console.ResetColor();

            // Add a new driver to the list
            rd.insertDriver(newDriver);
            //rd.insertVehicle(vehicle,newDriver.id);
            driverList.Add(newDriver);

        }
        public void updateDriver()
        {
            Console.Write(" Enter Driver Id: ");
            Console.ForegroundColor = ConsoleColor.Green;
            int id =int.Parse(Console.ReadLine());
            Admin admin=new Admin();
            Vehicle vehicle=new Vehicle();
            Console.ResetColor();


            //Check driver registered or not
            if (admin.isDriverRegistered(id)== true)
            {
                Console.WriteLine(" Driver with ID {0} does not exist.", id);
                return;

            }
            Console.WriteLine(" Driver found with ID {0}. Enter new data below:", id);

            //Update name
            Console.Write(" Name (leave empty to keep current value): ");
            Console.ForegroundColor = ConsoleColor.Green;
            string name = Console.ReadLine();
            Console.ResetColor();

            Driver driver = new Driver();
            if (!string.IsNullOrEmpty(name))
            {
                driver.Name = name;
            }

            //update gender
            Console.Write(" Gender (leave empty to keep current value): ");
            Console.ForegroundColor = ConsoleColor.Green;
            string gender = Console.ReadLine();
            Console.ResetColor();

            if (!string.IsNullOrEmpty(gender))
            {
                driver.Gender = gender;
            }


            //update address
            Console.Write(" Address Number (leave empty to keep current value): ");
            Console.ForegroundColor = ConsoleColor.Green;
            string address = Console.ReadLine();
            Console.ResetColor();

            if (!string.IsNullOrEmpty(address))
            {
                driver.Address = address;
            }

            //update vehicle type
            Console.Write(" Vehicle type (leave empty to keep current value): ");
            Console.ForegroundColor = ConsoleColor.Green;
            string type = Console.ReadLine();
            Console.ResetColor();

            if (!string.IsNullOrEmpty(type))
            {
                vehicle.Type = type;
            }

            //update vehicle model
            Console.Write(" Model (leave empty to keep current value): ");
            Console.ForegroundColor = ConsoleColor.Green;
            string model = Console.ReadLine();
            Console.ResetColor();

            if (!string.IsNullOrEmpty(model))
            {
                vehicle.Model = model;
            }

            //update license number
            Console.Write(" License number (leave empty to keep current value): ");
            Console.ForegroundColor = ConsoleColor.Green;
            string lic = Console.ReadLine();
            Console.ResetColor();

            if (!string.IsNullOrEmpty(lic))
            {
                vehicle.License_plate = lic;
            }


            RideDataBase rd = new RideDataBase();
            rd.updateDBDriver(driver);

        }
        public void removeDriver()
        {
            Console.WriteLine(" Enter id: ");
            Console.ForegroundColor = ConsoleColor.Green;
            int id =Convert.ToInt32(Console.ReadLine());
            Console.ResetColor();

            RideDataBase rd = new RideDataBase();
            rd.removeDBDriver(id);

            //for (int i=0; i<driverList.Count; i++)
            //{
            //    if (driverList[i].id==id)
            //    {
            //        driverList.RemoveAt(i);
            //        return;
            //    }

            //}


        }
        public void searchDriver()
        {
            int i_d = 0;

            Console.WriteLine("Enter Driver details..");

            Console.Write("Enter driver id: ");
            Console.ForegroundColor = ConsoleColor.Green;
            i_d = Convert.ToInt32(Console.ReadLine());
            Console.ResetColor();


            string name;
            int age = 0;
            string gender;
            string address;
            string type;
            string model;
            string license_plate;
            Console.Write("Enter Name: ");
            Console.ForegroundColor = ConsoleColor.Green;
            name = Console.ReadLine();
            Console.ResetColor();

            Console.Write("Enter Gender: ");
            Console.ForegroundColor = ConsoleColor.Green;
            gender = Console.ReadLine();
            Console.ResetColor();

            Console.Write("Enter Address: ");
            Console.ForegroundColor = ConsoleColor.Green;
            address = Console.ReadLine();
            Console.ResetColor();

            Console.Write("Enter Age: ");
            Console.ForegroundColor = ConsoleColor.Green;
            age = int.Parse(Console.ReadLine());
            Console.ResetColor();

            Console.Write("Enter model of your vehicle: ");
            Console.ForegroundColor = ConsoleColor.Green;
            model = Console.ReadLine();
            Console.ResetColor();

            Console.Write("Enter type of your vehicle: ");
            Console.ForegroundColor = ConsoleColor.Green;
            type = Console.ReadLine();
            Console.ResetColor();

            Console.Write("Enter license_plate of your vehicle: ");
            Console.ForegroundColor = ConsoleColor.Green;
            license_plate = Console.ReadLine();
            Console.ResetColor();

            // Making a Vehicle Object
            Vehicle vehicle = new Vehicle();
            vehicle.Model = model;
            vehicle.License_plate = license_plate;
            vehicle.Type = type;

            Driver driver = new Driver();
            driver.id = i_d;
            driver.Name = name;
            driver.Age = age;
            driver.Address = address;
            driver.Gender = gender;
            driver.Vehicle = vehicle;

            bool isDriverFound = false;

            foreach (Driver d in driverList)
            {
                if (d.id == driver.id || i_d == 0)
                {
                    isDriverFound = true;
                    driver.id = d.id;

                    if (d.Name == driver.Name || driver.Name == "")
                    {
                        isDriverFound = true;
                        driver.Name = d.Name;

                        if (d.Gender == driver.Gender || driver.Gender == "")
                        {
                            isDriverFound = true;
                            driver.Gender = d.Gender;

                            if (d.Age == driver.Age || driver.Age == 0)
                            {
                                isDriverFound = true;
                                driver.Age = d.Age;

                                if (d.Address == driver.Address || driver.Address == "")
                                {
                                    isDriverFound = true;
                                    driver.Address = d.Address;

                                    if (d.Vehicle.Type == driver.Vehicle.Type || driver.Vehicle.Type == "")
                                    {
                                        isDriverFound = true;
                                        driver.Vehicle.Type = d.Vehicle.Type;

                                        if (d.Vehicle.Model == driver.Vehicle.Model || driver.Vehicle.Model == "")
                                        {
                                            isDriverFound = true;
                                            driver.Vehicle.Model = d.Vehicle.Model;

                                            if (d.Vehicle.License_plate == driver.Vehicle.License_plate || driver.Vehicle.License_plate == "")
                                            {
                                                isDriverFound = true;
                                                driver.Vehicle.License_plate = d.Vehicle.License_plate;
                                            }
                                            else
                                            {
                                                isDriverFound = false;
                                            }
                                        }
                                        else
                                        {
                                            isDriverFound = false;
                                        }
                                    }
                                    else
                                    {
                                        isDriverFound = false;
                                    }
                                }
                                else
                                {
                                    isDriverFound = false;
                                }
                            }

                            else
                            {
                                isDriverFound = false;
                            }
                        }
                        else
                        {
                            isDriverFound = false;

                        }
                    }
                    else
                    {
                        isDriverFound = false;

                    }

                }
                else
                {
                    isDriverFound = false;

                }
                if (isDriverFound == true)
                {
                    Console.WriteLine("----------------------------------------------------------------------------------------------------\n");
                    Console.WriteLine($"Driver Id: {driver.id}, Name: {driver.Name}, Gender: {driver.Gender},Address: {driver.Address},Type: {driver.Vehicle.Type},Model: {driver.Vehicle.Model},License_Plate: {driver.Vehicle.License_plate}");
                    Console.WriteLine("\n-----------------------------------------------------------------------------------------------------");
                    return;
                }
            }

            if (isDriverFound == false)
            {
                Console.WriteLine("No Driver Found!");
            }

        }
        public List<Driver> getDriversList()
        {
            return Admin.driverList;
        }
        public bool isDriverRegistered(int id)
        {
            for(int i = 0; i < driverList.Count; i++)
            {
                if (id == driverList[i].id)
                    return true;
            }
            return false;
        }
       


    }
}
