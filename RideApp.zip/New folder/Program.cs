﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MyRide
{
    public class Program
    {
        static void Main(string[] args)
        {
            RideDataBase db = new RideDataBase();
            db.readData();
            while (true)
            {
                Console.WriteLine("\n");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\t\t\t------------------------------------------------------");
                Console.WriteLine("\t\t\t\tWELCOME TO MyRide");
                Console.WriteLine("\t\t\t------------------------------------------------------");               
                Console.WriteLine("\n");
                Console.WriteLine("\t\t\t1. Book a Ride");
                Console.WriteLine("\t\t\t2. Enter as Driver");
                Console.WriteLine("\t\t\t3. Enter as Admin");
                Console.Write("\t\t\tPress 1 to 3 to select an option: ");
                Console.ForegroundColor = ConsoleColor.Green;
                int option = Convert.ToInt32(Console.ReadLine());
                Console.ResetColor();

                //Objects of different classes
                Driver driver = new Driver();
                Admin admin = new Admin();
                Passenger passenger = new Passenger();

                switch (option)
                {
                    case 1:
                        Console.WriteLine("\n");
                        //In case1 user enter data for booking a ride
                        Ride ride = new Ride();

                        Console.Write(" Enter Name: ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        string name = Console.ReadLine();
                        passenger.Name = name;


                        Console.ResetColor();
                        Console.Write(" Enter Phone no: ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        string no = Console.ReadLine();
                        Console.ResetColor();

                        Console.Write(" Enter Ride Type: ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        string type = Console.ReadLine();

                        ride.assignPassenger(passenger);
                        ride.bookRide();

                        Console.ResetColor();
                        Console.WriteLine("-----------------THANK YOU--------------------");
                        ride.assignDriver(type);
                        Console.WriteLine(" Price for this ride is " + ride.calculatePrice(type));
                        Console.WriteLine(" Enter ‘Y’ if you want to Book the ride, enter ‘N’ if you want to cancel operation: ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        string ans = Console.ReadLine();
                        if (ans == "Y")
                        {
                            Console.ResetColor();
                            Console.WriteLine(" Happy Travel...!");
                            ride.giveRating();

                        }
                        else
                            continue;
                        break;
                    case 2:
                        Console.WriteLine("\n");

                        //Asked for driver related functionality
                        Console.Write(" Enter ID: ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        int id = Convert.ToInt32(Console.ReadLine());

                        Console.ResetColor();
                        Console.Write(" Enter Name: ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        string driverName = Console.ReadLine();
                        driver.Name = driverName;
                        if (admin.isDriverRegistered(id) == false)
                        {
                            Console.ResetColor();
                            Console.WriteLine(" Driver is not Registered ");
                        }
                        else
                        {
                            Console.WriteLine(" Hello " + driverName);
                            Console.Write(" Enter your current location: ");
                            Console.ForegroundColor = ConsoleColor.Green;
                            string currLoc = Console.ReadLine();
                            string[] c = currLoc.Split(',');
                            Location loc = new Location();

                            loc.setLocation(float.Parse(c[0]), float.Parse(c[1]));

                            Console.ResetColor();
                            Console.WriteLine("\t\t1. Change Availability");
                            Console.WriteLine("\t\t2. Change Location");
                            Console.WriteLine("\t\t3. Exit as Driver");
                            Console.ForegroundColor = ConsoleColor.Green;
                            int choice = Convert.ToInt32(Console.ReadLine());
                            Console.ResetColor();
                            if (choice == 1)
                            {
                                driver.updateAvailbility();
                            }
                            else if (choice == 2)
                            {
                                Console.Write(" Enter your current location: ");
                                Console.ForegroundColor = ConsoleColor.Green;
                                string currLocation = Console.ReadLine();
                                string[] curr = currLoc.Split(',');
                                Location locat = new Location();

                                locat.setLocation(float.Parse(c[0]), float.Parse(c[1]));
                                driver.updateLocation(locat);
                            }
                            else
                            {
                                Console.WriteLine(" Returning to Main Menu...");
                                continue;

                            }

                        }
                        break;

                    case 3:
                        Console.WriteLine("\n");
                        //admin view
                        Console.WriteLine(" 1. Add Driver\n 2. Remove Driver\n 3. Update Driver\n 4. Search Driver\n 5. Exit as Admin");
                        Console.Write(" Press 1 to 3 to select an option: ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        int val = Convert.ToInt32(Console.ReadLine());
                        Console.ResetColor();
                        if (val == 1)
                        {

                            admin.addDriver();

                        }
                        else if (val == 2)
                        {
                            admin.removeDriver();
                        }
                        else if (val == 3)
                        {
                            admin.updateDriver();
                        }
                        else if (val == 4)
                        {
                            admin.searchDriver();
                        }
                        else
                        {
                            Console.WriteLine(" Returning to Main Menu...");
                            return;
                        }

                        break;
                }





            }

        }
           
            
    }
}
