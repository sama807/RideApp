﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRide
{
    public class Vehicle
    {
        string type;
        string model;
        string license_plate;

        public Vehicle()
        { }
        public Vehicle(string t,string m,string p)
        {
            this.type = t;
            this.model = m;
            this.license_plate = p;
        }
        public string Type
        { 
            get; set; 
        }
        public string Model
        { 
            get; set; 
        }
        public string License_plate
        { 
            get; set; 
        }
    }
}

