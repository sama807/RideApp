﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;


namespace MyRide
{
    public class RideDataBase
    {
        public RideDataBase()
        {
        }
        public void readData()
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=myDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";    //Make Connection
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            //To Run Query
            string query = "select * from Driver";

            SqlCommand cmd = new SqlCommand(query,con);
            SqlDataReader dr= cmd.ExecuteReader();
            while(dr.Read())
            {
                Console.WriteLine(dr[0]);
                Console.WriteLine(dr[1]);
            }
            con.Close();
        }
        public void insertDriver(Driver d)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=myDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";    //Make Connection
            SqlConnection con = new SqlConnection(connectionString);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO Driver (Name, Gender, Phone, Age, Availability ,Address) VALUES (@Name, @Gender, @Phone, @Age, @Availability,@Address)";
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Name", d.Name);
                    command.Parameters.AddWithValue("@Gender", d.Gender);
                    command.Parameters.AddWithValue("@Phone", d.PhoneNo);
                    command.Parameters.AddWithValue("@Age", d.Age);
                    command.Parameters.AddWithValue("@Availability", d.Availability);
                    command.Parameters.AddWithValue("@Address", d.Address);
                    insertVehicle(d.Vehicle);
                    int rowsAffected = command.ExecuteNonQuery();
                    Console.WriteLine($"{rowsAffected} row(s) inserted.");
                }
            }

        }

        public void updateDBDriver(Driver d)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=myDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";    //Make Connection
            SqlConnection con = new SqlConnection(connectionString);

            string query = $"update Driver Set[Name] = {d.Name}, [Age] = {d.Age}, [Gender] = {d.Gender}, [Address] = {d.Address}, [PhoneNo] = {d.PhoneNo}, [Availability] = {d.Availability} where id = {d.id}";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int rows = cmd.ExecuteNonQuery();
            Console.WriteLine($"{rows} row(s) updated.");
            con.Close();
        }

        public void removeDBDriver(int id)
        {

            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=myDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";    //Make Connection
            SqlConnection con = new SqlConnection(connectionString);

            string query = $"delete from Driver where Driver_Id = {id}";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int rows = cmd.ExecuteNonQuery();
            Console.WriteLine($"{rows} row(s) removed.");
            con.Close();
        }
        public void insertVehicle(Vehicle veh)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=myDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";    //Make Connection
            SqlConnection con = new SqlConnection(connectionString);

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = $"insert into Vehicle(Type,Model,License_Plate) VALUES('{veh.Type}','{veh.Model}','{veh.License_plate}')";
            SqlCommand command = new SqlCommand(query, connection);
            int rows= command.ExecuteNonQuery();
            Console.WriteLine($"{rows} row(s) inserted.");

            con.Close();
        }

        public void insertLocation(Location loc, int id)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=myDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";    //Make Connection
            SqlConnection con = new SqlConnection(connectionString);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO Location (Longitude,Latitude) VALUES (@Longitude, @Latitude, @D_Id)";
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Longitude", loc.getLongitude());
                    command.Parameters.AddWithValue("@Latitude", loc.getLatitude());
                    command.Parameters.AddWithValue("@D_Id", id);

                    int rowsAffected = command.ExecuteNonQuery();
                    Console.WriteLine($"{rowsAffected} row(s) inserted.");
                }
            }

            con.Close();
        }

        public void insertPassenger(string name,string no)
        {
            string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=myDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";    //Make Connection
            SqlConnection con = new SqlConnection(connectionString);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO Passenger (Name,phone number) VALUES (@Name, @Phone number)";
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Name",name);
                    command.Parameters.AddWithValue("@Phone number", no);
                    int rowsAffected = command.ExecuteNonQuery();
                    Console.WriteLine($"{rowsAffected} row(s) inserted.");
                }
            }

            con.Close();
        }


    }

}
   


