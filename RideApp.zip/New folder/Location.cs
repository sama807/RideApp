﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRide
{
    public class Location
    {
        float latitude;
        float longitude;    
        public Location() { }
        public void setLocation(float longitude,float latitude)
        {
            this.latitude = latitude;   
            this.longitude = longitude;

        }
        //static public implicit operator Location(string start)
        //{
        //    return new Location { longitude = start[0], latitude = start[1] };
        //}
        public float getLatitude()
        {
            return latitude;
        }
        public float getLongitude()
        {
            return longitude;
        }

    }
}
