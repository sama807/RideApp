﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Threading.Tasks;

namespace MyRide
{
    public class Driver
    {
        string name;
        int age;
        int ID;
        string gender;
        string address;
        string phoneNo;
        Location curr_location;
        Vehicle vehicle;
        List<int> ratings;
        bool availability;
        public Driver()
        {
            curr_location = new Location();
            vehicle = new Vehicle();
            ratings = new List<int>();
            availability = false;
        }
        public Driver(string name, int age,string gender, string address, string phoneNo, Vehicle vehicle)
        {
            this.name = name;
            this.age = age;
            this.vehicle = vehicle;
            this.gender = gender;
            this.address = address;
            this.phoneNo = phoneNo;
            
        }

        public void updateAvailbility()
        {
            string status;
            Console.WriteLine("Enter availability status True or Flase): ");
            status = Console.ReadLine();
            if (status == "True")
            {
                this.availability = true;
            }
            else
            {
                this.availability = false;
            }
        }
        public int getRating()
        {
            Ride ride = new Ride();
            int avgRating = 0;
            int sum = 0;
            for (int i=0;i<ratings.Count;i++)
            {
                sum += ratings[i];
            }
            return avgRating=sum/ratings.Count;
            

        }
       
        public void updateLocation(Location loc)
        {
            this.curr_location = loc;
        }
        public int id
        {
            get; set;
        }
        public string Name
        { 
            get; set; 
        }
        public int Age
        { 
            get; set; 
        }
        public string Address
        {
            get; set;
        }
        public string Gender
        {
            get; set; 
        }
        public string PhoneNo
        {
            get; set;
        }  
        public Location Location
        {
            get; set;
        }
        public Location getCurrentLocation()
        {
            return curr_location;
        }
        public Vehicle Vehicle
        {
            get; set;
        }
        public bool Availability
        { 
            get; 
            set; 
        }
        public void setRating(int rating)
        {
            if (rating > 0 && rating <= 5)
            {
                ratings.Add(rating);


            }

        }
      

    }
}
