﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRide
{
    public class Ride
    {
        Location start_location;
        Location end_location;
        int price;
        Driver driver;
        Passenger passenger;
        private double calculateDistance(Location start,Location end)
        {
            //x= x2 - x1  
            //x1,y1 represents the longitude and latitude of start_loaction

            float x = start.getLongitude() - end.getLongitude();

            // y = y2 - y1
            //x2,y2 reprsents the longitude and latitude of end_location
            float y = start.getLatitude() - end.getLatitude();


            double d = (double)Math.Sqrt((x * x) + (y * y));
            return d;
        }
        public Ride()
        {
            driver = new Driver();
            passenger = new Passenger();
            start_location = new Location();
            end_location = new Location();
        }
        public Ride(Location start_location, Location end_location, Passenger passenger)
        {
            this.start_location = start_location;
            this.end_location = end_location;
            this.passenger = passenger;
         
        }

        public void setRideLocation(Location start,Location end)
        {
            this.start_location = start;
            this.end_location = end;
                                      
        }  
        public void assignPassenger(Passenger p)
        {
            this.passenger = p;

        }
        public void assignDriver(string type)
        {
            Admin admin = new Admin();
            List<Driver> drivers = admin.getDriversList();
            Driver d = new Driver();
            double distance = 0;
            double shortestDistance = 0;
            if (drivers.Count == 0)
            {
                //Console.WriteLine("No Driver Found");
                return;
            }
            // getting the distance of first driver from passenger and then checking all others
            distance = calculateDistance(start_location, drivers[0].getCurrentLocation());

            foreach (Driver driver in drivers)
            {
               
                distance = calculateDistance(start_location, driver.getCurrentLocation());
                if (distance < shortestDistance)
                {
                    if (driver.Availability)
                    {
                        if (driver.Vehicle.Type == type)
                        {
                            shortestDistance = distance;
                            d = driver;
                        }
                    }
                }
            }
            this.driver = d;
        }
        public void bookRide()
        {
            Console.ResetColor();
            Console.Write(" Enter Start Location: ");
            Console.ForegroundColor = ConsoleColor.Green;
            string start = Console.ReadLine();
            string[] s = start.Split(',');
            start_location.setLocation(float.Parse(s[0]), float.Parse(s[1]));

            Console.ResetColor();
            Console.Write(" Enter End Location: ");
            Console.ForegroundColor = ConsoleColor.Green;
            string end = Console.ReadLine();
            string[] e = end.Split(',');
            end_location.setLocation(float.Parse(e[0]), float.Parse(e[1]));


        }

        public void giveRating()
        {
            Console.Write(" Give rating out of 5: ");
            int userRating = Convert.ToInt32(Console.ReadLine());
            driver.setRating(userRating);
        }
        public int calculatePrice(string vehicleType)
        { 
            double d=calculateDistance(this.start_location, this.end_location);
            double fuelPrice = 280.09;
            
            if (vehicleType == "Bike")
            {
                price = (int)((d * fuelPrice) / 50) + (5 / 100);
            }
            else if (vehicleType == "Car")
            {
                price = (int)((d * fuelPrice) / 15) + (20 / 100);

            }
            else if (vehicleType == "Rickshaw")
            {
                price = (int)((d * fuelPrice) / 35) + (10 / 100);

            }
            else
            {
                Console.WriteLine(" Invalid Vehicle Type ");
            }
            
            return price;
        }
    }
}
