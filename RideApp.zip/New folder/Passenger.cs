﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRide
{
    public class Passenger
    {
        string name;
        string phoneNo;

        public Passenger()
        {}
        public Passenger(string name, string phoneNo)
        {
            this.name = name;
            this.phoneNo = phoneNo;
        }
        public string Name
        { get; set; }
        public string PhoneNo
        { get; set; }

    
}
}
